<template>
<div  class="mt-3 rounded-sm border border-slate-300 bg-white p-4 sm:p-6">
                <div class="mx-auto w-full max-w-6xl">
                    <div class="flex flex-wrap items-end justify-between gap-3">
                        <div>
                            <div class="text-xl font-extrabold text-slate-900 sm:text-2xl">STUDENT PAYMENT</div>
                            <div class="mt-2 h-[2px] w-full max-w-3xl bg-red-500"></div>
                        </div>

                        <div class="flex items-center gap-2">
                            <button
                                type="button"
                                class="rounded-t-md border border-b-0 px-4 py-2 text-sm font-extrabold"
                                :class="app.applyFeesTab === 'fees' ? 'border-blue-500 bg-white text-blue-700' : 'border-slate-300 bg-slate-50 text-slate-600 hover:bg-white'"
                                @click="setApplyFeesTab('fees')"
                            >
                                APPLICATION FEES
                            </button>
                            <button
                                type="button"
                                class="rounded-t-md border border-b-0 px-4 py-2 text-sm font-extrabold"
                                :class="app.applyFeesTab === 'certificate' ? 'border-blue-500 bg-white text-blue-700' : 'border-slate-300 bg-slate-50 text-slate-600 hover:bg-white'"
                                @click="setApplyFeesTab('certificate')"
                            >
                                APPLY FOR CERTIFICATE
                            </button>
                        </div>
                    </div>

                    <div class="mt-4 rounded-sm border border-slate-300 bg-white p-4 sm:p-6">

                    <div v-if="app.applyFeesStatusMessage" class="mt-6 rounded-sm border p-3 text-sm" :class="app.applyFeesStatusClass">
                        {{ app.applyFeesStatusMessage }}
                        <span v-if="app.applyFeesTranId" class="font-semibold"> ({{ app.applyFeesTranId }})</span>
                    </div>

                        <div v-if="app.applyFeesTab === 'fees'">
                            <div v-if="app.applyFeesLoading" class="mt-6 text-sm text-slate-600">Loading...</div>
                            <div v-else>
                                <div v-if="app.applyFeesError" class="mt-6 rounded-sm border border-red-200 bg-red-50 p-3 text-sm text-red-800">
                                    {{ app.applyFeesError }}
                                </div>

                                <form class="mt-8" @submit.prevent="submitApplyFees">
                                    <div class="grid grid-cols-1 gap-6 md:grid-cols-3">
                                        <div class="space-y-4">
                                            <input v-model="app.applyFeesForm.name" type="text" placeholder="Full Name" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required />
                                            <input v-model="app.applyFeesForm.mobile" type="text" placeholder="Mobile" class="h-10 w-full rounded-sm border border-slate-300 bg-[#eaf2ff] px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required />
                                            <input v-model="app.applyFeesForm.admission_roll" type="text" placeholder="Application ID / Admission Roll" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required />
                                        </div>

                                        <div class="space-y-4">
                                            <select v-model="app.applyFeesForm.academic_session_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                <option value="">Session</option>
                                                <option v-for="s in app.applyFeesSessionsSorted" :key="'afs-' + s.id" :value="String(s.id)">{{ s.name }}</option>
                                            </select>

                                            <select v-model="app.applyFeesForm.academic_qualification_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                <option value="">Academic Level</option>
                                                <option v-for="q in app.applyFeesQualifications" :key="'afq-' + q.id" :value="String(q.id)">{{ q.name }}</option>
                                            </select>

                                            <select v-model="app.applyFeesForm.department_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                <option value="">Department/Group</option>
                                                <option v-for="d in app.applyFeesFilteredDepartments" :key="'afd-' + d.id" :value="String(d.id)">{{ d.name }}</option>
                                            </select>

                                            <select v-model="app.applyFeesForm.academic_class_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                <option value="">Class</option>
                                                <option v-for="c in app.applyFeesFilteredClasses" :key="'afc-' + c.id" :value="String(c.id)">{{ c.name }}</option>
                                            </select>
                                        </div>

                                        <div class="space-y-4">
                                            <select v-model="app.applyFeesForm.purpose_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                <option value="">Fees</option>
                                                <option v-for="p in app.applyFeesPurposes" :key="'afp-' + p.id" :value="String(p.id)">{{ p?.head?.name || '' }}</option>
                                            </select>

                                            <div class="rounded-sm border border-slate-300 bg-slate-50 p-4 text-sm text-slate-700">
                                                <div class="font-semibold">Amount</div>
                                                <div class="mt-1 text-lg font-extrabold text-slate-900">{{ app.applyFeesSelectedAmountText }}</div>
                                            </div>

                                            <div v-if="app.applyFeesInvoiceError" class="rounded-sm border border-red-200 bg-red-50 p-3 text-sm text-red-800">
                                                {{ app.applyFeesInvoiceError }}
                                            </div>
                                            <div v-else-if="app.applyFeesInvoice" class="rounded-sm border border-slate-300 bg-white p-3 text-sm text-slate-700">
                                                <div class="font-semibold text-slate-900">Invoice: {{ app.applyFeesInvoice.invoice_number || '—' }}</div>
                                                <div class="mt-1">Status: <span class="font-semibold">{{ app.applyFeesInvoice.status || '—' }}</span></div>
                                                <div class="mt-1">Amount: <span class="font-semibold">{{ Number(app.applyFeesInvoice.amount || 0).toFixed(2) }}</span></div>
                                                <button
                                                    v-if="String(app.applyFeesInvoice.status || '') !== 'success' && app.applyFeesInvoice.invoice_number"
                                                    type="button"
                                                    class="mt-3 rounded-sm bg-[#0b1d4d] px-4 py-2 text-xs font-extrabold text-white hover:bg-[#09163c]"
                                                    :disabled="app.applyFeesPayExistingLoading"
                                                    @click="payApplyFeesExisting"
                                                >
                                                    {{ app.applyFeesPayExistingLoading ? 'Processing...' : 'Pay This Invoice' }}
                                                </button>
                                            </div>

                                            <div class="mt-2 flex items-center justify-between gap-3">
                                                <button
                                                    type="button"
                                                    class="rounded-sm border border-emerald-600 bg-white px-4 py-2 text-sm font-extrabold text-emerald-700 hover:bg-emerald-50"
                                                    :disabled="app.applyFeesInvoiceLoading"
                                                    @click="checkApplyFeesInvoice"
                                                >
                                                    {{ app.applyFeesInvoiceLoading ? 'Checking...' : 'Check Invoice' }}
                                                </button>

                                                <button type="submit" class="rounded-sm bg-[#0b1d4d] px-10 py-2.5 text-sm font-extrabold text-white hover:bg-[#09163c]" :disabled="app.applyFeesSubmitting">
                                                    {{ app.applyFeesSubmitting ? 'Processing...' : 'Pay Now' }}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div v-else>
                            <div v-if="app.certificateLoading" class="mt-6 text-sm text-slate-600">Loading...</div>
                            <div v-else>
                                <div v-if="app.certificateError" class="mt-6 rounded-sm border border-red-200 bg-red-50 p-3 text-sm text-red-800">
                                    {{ app.certificateError }}
                                </div>

                                <form class="mt-8" @submit.prevent="submitCertificate">
                                    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
                                        <div class="rounded-sm border border-slate-300 bg-white p-4">
                                            <div class="border-l-4 border-orange-500 pl-3 text-sm font-extrabold text-slate-900">STUDENT INFO</div>

                                            <div class="mt-4 flex items-center gap-2">
                                                <input
                                                    v-model="app.certificateForm.mobile"
                                                    type="text"
                                                    placeholder="Mobile"
                                                    class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10"
                                                    required
                                                />
                                                <button
                                                    type="button"
                                                    class="h-10 w-12 rounded-sm border border-slate-300 bg-slate-50 text-sm font-extrabold text-slate-700 hover:bg-white"
                                                    :disabled="app.app.certificateLookupLoading"
                                                    @click="app.certificateLookup"
                                                >
                                                    {{ app.app.certificateLookupLoading ? '…' : 'Go' }}
                                                </button>
                                            </div>
                                            <div v-if="app.app.certificateLookupError" class="mt-3 rounded-sm border border-red-200 bg-red-50 p-2 text-xs text-red-800">{{ app.app.certificateLookupError }}</div>

                                            <div class="mt-4 text-sm font-semibold text-slate-800">Certificate Type :</div>
                                            <div class="mt-2 flex flex-wrap items-center gap-4 text-sm text-slate-700">
                                                <label class="inline-flex items-center gap-2">
                                                    <input v-model="app.certificateForm.app.certificate_type" type="radio" name="app.certificate_type" value="en" />
                                                    English
                                                </label>
                                                <label class="inline-flex items-center gap-2">
                                                    <input v-model="app.certificateForm.app.certificate_type" type="radio" name="app.certificate_type" value="bn" />
                                                    Bangla
                                                </label>
                                                <label class="inline-flex items-center gap-2">
                                                    <input v-model="app.certificateForm.app.certificate_type" type="radio" name="app.certificate_type" value="both" />
                                                    Both
                                                </label>
                                            </div>

                                            <div class="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                                                <input v-model="app.certificateForm.student_name_en" type="text" placeholder="Student name (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.student_name_bn" type="text" placeholder="Student name (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.fathers_name_en" type="text" placeholder="Father's name (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.fathers_name_bn" type="text" placeholder="Father's name (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.mothers_name_en" type="text" placeholder="Mother's name (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.mothers_name_bn" type="text" placeholder="Mother's name (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.academic_year_en" type="text" placeholder="Academic year (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.academic_year_bn" type="text" placeholder="Academic year (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.registration_no_en" type="text" placeholder="Registration no (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.registration_no_bn" type="text" placeholder="Registration no (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.exam_roll_en" type="text" placeholder="Exam roll (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.exam_roll_bn" type="text" placeholder="Exam roll (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.exam_year_en" type="text" placeholder="Exam year (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.exam_year_bn" type="text" placeholder="Exam year (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.gpa_en" type="text" placeholder="GPA (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.gpa_bn" type="text" placeholder="GPA (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />

                                                <input v-model="app.certificateForm.division_en" type="text" placeholder="Division (EN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateEnDisabled" :required="!app.certificateEnDisabled" />
                                                <input v-model="app.certificateForm.division_bn" type="text" placeholder="Division (BN)" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :disabled="app.certificateBnDisabled" :required="!app.certificateBnDisabled" />
                                            </div>
                                        </div>

                                        <div class="rounded-sm border border-slate-300 bg-white p-4">
                                            <div class="border-l-4 border-orange-500 pl-3 text-sm font-extrabold text-slate-900">APPLY FOR CERTIFICATE</div>

                                            <div class="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                                                <select v-model="app.certificateForm.academic_session_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                    <option value="">--Select Session--</option>
                                                    <option v-for="s in app.certificateSessionsSorted" :key="'cs-' + s.id" :value="String(s.id)">{{ s.name }}</option>
                                                </select>

                                                <select v-model="app.certificateForm.template_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                    <option value="">--Select Certificate--</option>
                                                    <option v-for="t in app.certificateFilteredTemplates" :key="'ct-' + t.id" :value="String(t.id)">{{ t.title }}</option>
                                                </select>

                                                <select v-model="app.certificateForm.academic_qualification_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" required>
                                                    <option value="">--Select Academic Level--</option>
                                                    <option v-for="q in app.certificateQualifications" :key="'cq-' + q.id" :value="String(q.id)">{{ q.name }}</option>
                                                </select>

                                                <select v-model="app.certificateForm.department_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :required="app.certificateDepartmentRequired">
                                                    <option value="">--Select Department/Group--</option>
                                                    <option v-for="d in app.certificateFilteredDepartments" :key="'cd-' + d.id" :value="String(d.id)">{{ d.name }}</option>
                                                </select>
                                            </div>

                                            <div v-if="app.certificateClasses && app.certificateClasses.length" class="mt-3">
                                                <select v-model="app.certificateForm.academic_class_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" :required="app.certificateClassRequired">
                                                    <option value="">--Select Class--</option>
                                                    <option v-for="c in app.certificateFilteredClasses" :key="'cc-' + c.id" :value="String(c.id)">{{ c.name }}</option>
                                                </select>
                                            </div>

                                            <div class="mt-4 rounded-sm border border-slate-300 bg-slate-50 p-4 text-sm text-slate-700">
                                                <div class="font-semibold">Amount</div>
                                                <div class="mt-1 text-lg font-extrabold text-slate-900">{{ app.certificateSelectedAmountText }}</div>
                                            </div>

                                            <div class="mt-6 text-center">
                                                <button type="submit" class="rounded-sm bg-[#0b1d4d] px-10 py-2.5 text-sm font-extrabold text-white hover:bg-[#09163c]" :disabled="app.certificateSubmitting">
                                                    {{ app.certificateSubmitting ? 'Submitting...' : 'SUBMIT' }}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
</template>

<script setup>
import { inject } from 'vue'
const app = inject('app')
</script>
<template>
<div  class="mt-3 rounded-sm border border-slate-300 bg-white p-4 sm:p-6">
                <div class="mx-auto w-full max-w-3xl">
                    <div v-if="app.onlineAdmissionStatusMessage" class="mb-4 rounded-sm border p-3 text-sm" :class="app.onlineAdmissionStatusClass">
                        {{ app.onlineAdmissionStatusMessage }}
                        <span v-if="app.onlineAdmissionTranId" class="font-semibold"> ({{ app.onlineAdmissionTranId }})</span>
                    </div>

                    <div v-if="app.studentMe" class="rounded-sm border border-red-200 bg-red-50 p-4 text-center text-sm font-semibold text-red-800">
                        You are already logged in, logout to access this page
                    </div>

                    <template v-else>
                        <div class="flex items-center justify-between gap-3 border-b border-slate-300 pb-3">
                            <div class="text-lg font-extrabold text-slate-900">ADMISSION PAYMENT</div>
                            <button type="button" class="rounded-sm bg-[#2f855a] px-4 py-2 text-sm font-extrabold text-white hover:bg-[#276f4a]" @click="app.go('/online-admission-invoice')">Pay Slip</button>
                        </div>

                        <div v-if="app.onlineAdmissionPaymentError" class="mt-4 rounded-sm border border-red-200 bg-red-50 p-3 text-sm text-red-800">{{ app.onlineAdmissionPaymentError }}</div>

                        <div class="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-12">
                            <div class="sm:col-span-9 space-y-3">
                                <input v-model="app.onlineAdmissionPaymentForm.mobile" type="text" placeholder="Mobile" :readonly="app.onlineAdmissionPaymentReadonly" class="h-10 w-full rounded-sm border border-slate-300 bg-[#eaf2ff] px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" />
                                <input v-model="app.onlineAdmissionPaymentForm.admission_roll" type="text" placeholder="Admission Roll / Reg No" :readonly="app.onlineAdmissionPaymentReadonly" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none focus:border-[#0d6b75] focus:ring-2 focus:ring-[#0d6b75]/10" />
                            </div>
                            <div class="sm:col-span-3 flex flex-col items-stretch justify-start gap-2">
                                <button v-if="app.onlineAdmissionPaymentReadonly" type="button" class="rounded-sm bg-[#d20808] px-4 py-2 text-sm font-extrabold text-white hover:bg-[#b60606]" @click="app.onlineAdmissionPaymentReset">RESET</button>
                                <button v-else-if="!app.onlineAdmissionPaymentHeadsLoading" type="button" class="rounded-sm bg-[rgb(39,112,154)] px-4 py-2 text-sm font-extrabold text-white hover:bg-[rgb(32,93,128)]" @click="app.onlineAdmissionGetPaymentHeads">CHECK</button>
                                <div v-else class="text-sm text-slate-600">processing..</div>
                            </div>
                        </div>

                        <div v-if="app.onlineAdmissionPaymentHeads.length" class="mt-4 space-y-3">
                            <select v-model="app.onlineAdmissionPaymentForm.account_head_id" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none" @change="app.onlineAdmissionSelectPaymentPurpose">
                                <option value="">Fees</option>
                                <option v-for="p in app.onlineAdmissionPaymentHeads" :key="'oaph-' + p.account_head_id" :value="String(p.account_head_id)">{{ p.account_head?.name || '' }}</option>
                            </select>
                            <input v-model="app.onlineAdmissionPaymentForm.amount" type="text" placeholder="Amount" :readonly="app.onlineAdmissionPaymentAmountReadonly" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none" />
                            <div class="grid grid-cols-1 gap-3 sm:grid-cols-12">
                                <div class="sm:col-span-4 pt-2 text-sm font-semibold text-slate-700">Service Charge</div>
                                <div class="sm:col-span-8">
                                    <input :value="app.onlineAdmissionPaymentChargeAmount" readonly type="text" placeholder="Service Charge" class="h-10 w-full rounded-sm border border-slate-300 bg-slate-50 px-3 text-sm outline-none" />
                                </div>
                            </div>
                        </div>

                        <div v-if="Number(app.onlineAdmissionPaymentForm.amount || 0) > 0" class="mt-6 text-center">
                            <button
                                v-if="!app.onlineAdmissionPaymentSubmitting"
                                type="button"
                                class="rounded-sm bg-[#0b1d4d] px-10 py-2.5 text-sm font-extrabold text-white hover:bg-[#09163c]"
                                :disabled="app.onlineAdmissionPaymentPayFirst"
                                @click="app.onlineAdmissionPayNow"
                            >
                                PAY NOW
                            </button>
                            <div v-else class="text-sm text-slate-600">processing..</div>
                        </div>
                    </template>
                </div>
            </div>

            
</template>

<script setup>
import { inject } from 'vue'
const app = inject('app')
</script>
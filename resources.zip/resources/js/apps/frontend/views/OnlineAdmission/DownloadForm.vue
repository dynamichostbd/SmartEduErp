<template>
<div  class="mt-3 rounded-sm border border-slate-300 bg-white p-4 sm:p-6">
                <div class="mx-auto w-full max-w-5xl">
                    <div v-if="app.studentMe" class="rounded-sm border border-red-200 bg-red-50 p-4 text-center text-sm font-semibold text-red-800">
                        You are already logged in, logout to access this page
                    </div>
                    <template v-else>
                        <div class="flex items-center justify-between gap-3 border-b border-slate-300 pb-3">
                            <div class="text-lg font-extrabold text-slate-900">DOWNLOAD FORM</div>
                            <button type="button" class="rounded-sm bg-[#2b6cb0] px-4 py-2 text-sm font-extrabold text-white hover:bg-[#245a94]" @click="app.go('/online-admission-payment')">Payment</button>
                        </div>

                        <div class="mt-6 grid grid-cols-1 items-center gap-3 sm:grid-cols-12">
                            <div class="sm:col-span-4">
                                <input v-model="app.onlineAdmissionDownloadSearch.admission_roll" type="text" placeholder="Admission Roll / Reg No" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none" />
                            </div>
                            <div class="sm:col-span-4">
                                <input v-model="app.onlineAdmissionDownloadSearch.mobile" type="text" placeholder="Mobile Number" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none" />
                            </div>
                            <div class="sm:col-span-4">
                                <button v-if="!app.onlineAdmissionDownloadLoading" type="button" class="rounded-sm bg-[#2f855a] px-5 py-2 text-sm font-extrabold text-white hover:bg-[#276f4a]" @click="app.onlineAdmissionSearchDownloadForm">Search</button>
                                <div v-else class="text-sm text-slate-600">processing..</div>
                            </div>
                        </div>

                        <div v-if="app.onlineAdmissionDownloadError" class="mt-4 rounded-sm border border-red-200 bg-red-50 p-3 text-sm text-red-800">{{ app.onlineAdmissionDownloadError }}</div>

                        <div class="mt-6">
                            <template v-if="app.onlineAdmissionDownloadShow">
                                <template v-if="app.onlineAdmissionDownloadData">
                                    <div class="text-center">
                                        <button v-if="!app.onlineAdmissionDownloadPdfLoading" type="button" class="rounded-sm bg-[#2b6cb0] px-5 py-2 text-sm font-extrabold text-white hover:bg-[#245a94]" @click="app.onlineAdmissionDownloadPdf">Download Admission Form</button>
                                        <div v-else class="text-sm text-slate-600">processing..</div>
                                    </div>
                                    <div class="mt-4 rounded-sm border border-slate-300 bg-white p-4">
                                        <table class="w-full text-sm">
                                            <tbody>
                                                <tr class="border-b"><th class="py-2 pr-3 text-left">Admission Roll</th><td class="py-2">{{ app.onlineAdmissionDownloadData.admission_roll }}</td></tr>
                                                <tr class="border-b"><th class="py-2 pr-3 text-left">Mobile</th><td class="py-2">{{ app.onlineAdmissionDownloadData.mobile }}</td></tr>
                                                <tr class="border-b"><th class="py-2 pr-3 text-left">Fathers Name</th><td class="py-2">{{ app.onlineAdmissionDownloadData.fathers_name }}</td></tr>
                                                <tr class="border-b"><th class="py-2 pr-3 text-left">Mothers Name</th><td class="py-2">{{ app.onlineAdmissionDownloadData.mothers_name }}</td></tr>
                                                <tr><th class="py-2 pr-3 text-left">Address</th><td class="py-2">{{ app.onlineAdmissionDownloadData.address }}</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </template>
                                <div v-else class="rounded-sm border border-slate-300 bg-slate-50 p-4 text-center text-sm text-slate-700">Sorry!! admission form not found</div>
                            </template>
                            <div v-else class="rounded-sm border border-slate-300 bg-slate-50 p-4 text-center text-sm text-slate-700">Please input your admission roll and your mobile number for admission form</div>
                        </div>
                    </template>
                </div>
            </div>

            
</template>

<script setup>
import { inject } from 'vue'
const app = inject('app')
</script>
<template>
<div  class="mt-3 rounded-sm border border-slate-300 bg-white p-4 sm:p-6">
                <div class="mx-auto w-full max-w-5xl">
                    <div v-if="app.studentMe" class="rounded-sm border border-red-200 bg-red-50 p-4 text-center text-sm font-semibold text-red-800">
                        You are already logged in, logout to access this page
                    </div>
                    <template v-else>
                        <div class="flex items-center justify-between gap-3 border-b border-slate-300 pb-3">
                            <div class="text-lg font-extrabold text-slate-900">PAY SLIP</div>
                            <button type="button" class="rounded-sm bg-[#2b6cb0] px-4 py-2 text-sm font-extrabold text-white hover:bg-[#245a94]" @click="app.go('/online-admission-payment')">Payment</button>
                        </div>

                        <div class="mt-6 grid grid-cols-1 items-center gap-3 sm:grid-cols-12">
                            <div class="sm:col-span-4">
                                <input v-model="app.onlineAdmissionInvoiceSearch.admission_roll" type="text" placeholder="Admission Roll / Reg No" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none" />
                            </div>
                            <div class="sm:col-span-4">
                                <input v-model="app.onlineAdmissionInvoiceSearch.mobile" type="text" placeholder="Mobile Number" class="h-10 w-full rounded-sm border border-slate-300 bg-white px-3 text-sm outline-none" />
                            </div>
                            <div class="sm:col-span-4">
                                <button v-if="!app.onlineAdmissionInvoiceLoading" type="button" class="rounded-sm bg-[#2f855a] px-5 py-2 text-sm font-extrabold text-white hover:bg-[#276f4a]" @click="app.onlineAdmissionSearchInvoices">Search</button>
                                <div v-else class="text-sm text-slate-600">processing..</div>
                            </div>
                        </div>

                        <div v-if="app.onlineAdmissionInvoiceError" class="mt-4 rounded-sm border border-red-200 bg-red-50 p-3 text-sm text-red-800">{{ app.onlineAdmissionInvoiceError }}</div>

                        <div class="mt-6 space-y-4">
                            <div v-if="app.onlineAdmissionInvoicesShow">
                                <div v-if="app.onlineAdmissionInvoices.length">
                                    <div v-for="(inv, idx) in app.onlineAdmissionInvoices" :key="'oainv-' + idx" class="rounded-sm border border-slate-300 p-4">
                                        <div class="flex flex-wrap items-center justify-between gap-3">
                                            <div class="text-sm font-semibold text-slate-700">
                                                <div><span class="font-extrabold">Invoice:</span> {{ inv.invoice_number }}</div>
                                                <div><span class="font-extrabold">Date:</span> {{ inv.invoice_date || '—' }}</div>
                                                <div><span class="font-extrabold">Status:</span> {{ inv.status }}</div>
                                            </div>
                                            <div class="flex flex-wrap items-center gap-2">
                                                <button type="button" class="rounded-sm bg-[#2b6cb0] px-3 py-2 text-xs font-extrabold text-white hover:bg-[#245a94]" @click="app.onlineAdmissionOpenInvoice(inv.id)">PRINT</button>
                                                <button type="button" class="rounded-sm bg-[#2f855a] px-3 py-2 text-xs font-extrabold text-white hover:bg-[#276f4a]" @click="app.onlineAdmissionDownloadInvoice(inv.id)">Download Invoice</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-else class="rounded-sm border border-slate-300 bg-slate-50 p-4 text-center text-sm text-slate-700">Sorry!! invoice not found, please try again</div>
                            </div>
                            <div v-else class="rounded-sm border border-slate-300 bg-slate-50 p-4 text-center text-sm text-slate-700">Please input your admission roll and your mobile number for invoice</div>
                        </div>
                    </template>
                </div>
            </div>

            
</template>

<script setup>
import { inject } from 'vue'
const app = inject('app')
</script>
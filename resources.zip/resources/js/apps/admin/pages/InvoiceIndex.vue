<template>
    <div class="flex flex-col gap-4">
        <div class=" border border-slate-300 bg-white p-5">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div class="min-w-0">
                    <div class="truncate text-xl font-semibold text-slate-900">{{ pageHeading }}</div>
                    <div class="mt-1 text-sm text-slate-600">Invoices</div>
                </div>

                <div class="flex flex-wrap items-center gap-2">
                    <button type="button" class="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50" @click="goDashboard">
                        <i class="fas fa-tachometer-alt mr-2"></i>
                        Dashboard
                    </button>
                    <button type="button" class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700" @click="goCreate">
                        <i class="fas fa-plus mr-2"></i>
                        Create
                    </button>
                </div>
            </div>
        </div>

        <div v-if="error" class=" border border-red-200 bg-red-50 p-4 text-sm text-red-800">{{ error }}</div>

        <div class=" border border-slate-300 bg-white p-5">
            <div class="grid grid-cols-1 gap-3 lg:grid-cols-12">
                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Status</div>
                    <select v-model="filters.status" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option value="pending">Dues</option>
                        <option value="success">Paid</option>
                        <option value="failed">Failed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Session</div>
                    <select v-model="filters.academic_session_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="s in sessionsSorted" :key="'ses-' + s.id" :value="String(s.id)">{{ s.name }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Academic Level</div>
                    <select v-model="filters.academic_qualification_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="q in qualifications" :key="'q-' + q.id" :value="String(q.id)">{{ q.name }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Department</div>
                    <select v-model="filters.department_id" :disabled="!filters.academic_qualification_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="d in filteredDepartments" :key="'d-' + d.id" :value="String(d.id)">{{ d.name }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Class</div>
                    <select v-model="filters.academic_class_id" :disabled="!filters.academic_qualification_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="c in filteredClasses" :key="'c-' + c.id" :value="String(c.id)">{{ c.name }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Student Type</div>
                    <select v-model="filters.student_type" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="t in studentTypes" :key="'t-' + t" :value="t">{{ t }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">From Date</div>
                    <input v-model="filters.from_date" type="date" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">To Date</div>
                    <input v-model="filters.to_date" type="date" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                </div>

                <div v-if="mode === 'accountHeadWise'" class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">All Account Head</div>
                    <select v-model="filters.account_head_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="h in accountHeads" :key="'ah-' + h.id" :value="String(h.id)">{{ h.name }}</option>
                    </select>
                </div>

                <div v-if="mode === 'accountWise'" class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">All Account</div>
                    <select v-model="filters.payment_gateway_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="a in accountsCommons" :key="'acc-' + a.id" :value="String(a.id)">{{ a.account_no }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Exam</div>
                    <select v-model="filters.exam_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                        <option value="">All</option>
                        <option v-for="e in exams" :key="'ex-' + e.id" :value="String(e.id)">{{ e.name }}</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Exam Year</div>
                    <input v-model="filters.examination_year" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" placeholder="Year" />
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Search Field</div>
                    <select v-model="filters.field_name" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-slate-300 focus:ring-2 focus:ring-slate-200" :disabled="loading">
                        <option value="">Select Field</option>
                        <option value="name">Name</option>
                        <option value="mobile">Mobile</option>
                        <option value="college_roll">College Roll</option>
                        <option value="admission_id">Admission ID</option>
                        <option value="reg_no">Reg No</option>
                        <option value="invoice_number">Invoice Number</option>
                    </select>
                </div>

                <div class="lg:col-span-2">
                    <div class="text-xs font-semibold text-slate-600">Search</div>
                    <input v-model="filters.value" type="text" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" @keydown.enter.prevent="load(1)" />
                </div>

                <div class="lg:col-span-1 flex items-end gap-2">
                    <button type="button" class="h-9 w-full rounded-lg bg-emerald-600 px-4 text-sm font-semibold text-white hover:bg-emerald-700" :disabled="loading" @click="load(1)">
                        <i v-if="loading" class="fas fa-spinner fa-spin mr-2"></i>
                        <i v-else class="fas fa-search mr-2"></i>
                        {{ loading ? '...' : 'Go' }}
                    </button>
                </div>

                <div class="lg:col-span-2 flex items-end">
                    <button type="button" class="h-9 w-full rounded-lg border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50" @click="printInvoice">
                        <i class="fas fa-print mr-2"></i>
                        Print Invoice
                    </button>
                </div>
            </div>
        </div>

        <div class="border border-slate-300 bg-white">
            <div class="overflow-x-auto">
                <table class="min-w-[600px] w-full border-collapse border border-slate-300 text-sm">
                    <thead class="bg-slate-50">
                        <tr class="text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">Student</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">Admission ID</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">College Roll</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">Dept. / Group</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">Academic Level / Class</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">Purpose</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-slate-700 whitespace-nowrap">Invoice</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-right text-slate-700 whitespace-nowrap">Amount</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-center text-slate-700 whitespace-nowrap">Status</th>
                            <th class="border border-slate-300 bg-slate-50 px-1 py-2 text-center text-slate-700 whitespace-nowrap">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <tr v-for="(row, idx) in rows" :key="'r-' + row.id" :class="idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'">
                            <td class="border border-slate-300 px-1 py-1">
                                <div v-if="row.student">
                                    <div class="font-semibold text-slate-900 whitespace-nowrap">{{ row.student.name }}</div>
                                    <div class="text-xs text-slate-600">{{ row.student.mobile }}</div>
                                </div>
                                <div v-else-if="row.online_admission">
                                    <div class="font-semibold text-slate-900">{{ row.online_admission.name }}</div>
                                    <div class="text-xs text-slate-600">{{ row.online_admission.mobile }}</div>
                                </div>
                            </td>
                            <td class="border border-slate-300 px-1 py-1">
                                <span v-if="row.student">{{ row.student.admission_id }}</span>
                                <span v-else-if="row.online_admission">{{ row.online_admission.admission_roll }}</span>
                            </td>
                            <td class="border border-slate-300 px-1 py-1">
                                <span v-if="row.student">{{ row.student.college_roll || '' }}</span>
                                <span v-else-if="row.online_admission">{{ row.online_admission.college_roll || '' }}</span>
                            </td>
                            <td class="border border-slate-300 px-1 py-1">{{ row.department ? row.department.name : '' }}</td>
                            <td class="border border-slate-300 px-1 py-1">
                                <div>{{ row.qualification ? row.qualification.name : '' }}</div>
                                <div class="text-xs text-slate-600">({{ row.academic_class ? row.academic_class.name : '' }})</div>
                            </td>
                            <td class="border border-slate-300 px-1 py-1">{{ row.head ? row.head.name : '' }}</td>
                            <td class="border border-slate-300 px-1 py-1">
                                <div class="space-y-1">
                                    <div class="font-semibold text-emerald-700 hover:underline whitespace-nowrap">{{ row.invoice_number }}</div>
                                    <div class="font-semibold text-emerald-700 whitespace-nowrap">{{ formatDate(row.invoice_date) }}</div>
                                </div>
                            </td>
                            <td class="border border-slate-300 px-1 py-1 font-semibold">{{ money(row.amount) }}</td>
                            <td class="border border-slate-300 px-1 py-1 text-center">
                                <span
                                    class="inline-flex rounded-full px-1 py-0.5 text-xs font-semibold"
                                    :class="row.status === 'success' ? 'bg-emerald-50 text-emerald-700' : row.status === 'pending' ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-700'"
                                >
                                    {{ (row.status || '').toUpperCase() }}
                                </span>
                            </td>
                            <td class="border border-slate-300 px-1 py-1 text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <button
                                        type="button"
                                        class="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                                        title="Edit"
                                        @click="editInvoice(row.id)"
                                    >
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button
                                        v-if="row.status !== 'success'"
                                        type="button"
                                        class="inline-flex h-8 w-8 items-center justify-center rounded-md border border-red-200 bg-white text-red-700 hover:bg-red-50"
                                        title="Delete"
                                        @click="deleteInvoice(row.id)"
                                    >
                                        <i v-if="deletingId === row.id" class="fas fa-spinner fa-spin"></i>
                                        <i v-else class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="!rows.length">
                            <td colspan="11" class="px-3 py-10 text-center text-slate-500">No Data Found</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div v-if="meta.total > 0" class="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div class="text-sm text-slate-600">Showing {{ meta.from }} to {{ meta.to }} of {{ meta.total }} entries</div>

                <div class="flex items-center gap-2">
                    <button type="button" class="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 hover:bg-slate-50" :disabled="meta.current_page <= 1" @click="load(meta.current_page - 1)">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <div class="text-sm font-semibold text-slate-700">{{ meta.current_page }} / {{ meta.last_page }}</div>
                    <button type="button" class="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 hover:bg-slate-50" :disabled="meta.current_page >= meta.last_page" @click="load(meta.current_page + 1)">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Edit Modal -->
        <div v-if="showEditModal" class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/30">
            <div class="flex min-h-full items-center justify-center p-4">
                <div class="relative w-full max-w-2xl rounded-lg bg-white p-6 shadow-xl">
                    <div class="mb-4 flex items-center justify-between">
                        <h3 class="text-lg font-semibold text-slate-900">Edit Invoice</h3>
                        <button type="button" class="text-slate-400 hover:text-slate-600" @click="showEditModal = false">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="md:col-span-2 border-b pb-3">
                            <div class="text-sm text-slate-600">
                                <div>Invoice No: <span class="font-semibold text-slate-900">{{ editInvoiceData.invoice_number }}</span></div>
                                <div>Current Status: <span class="font-semibold text-slate-900">{{ (editInvoiceData.current_status || '').toUpperCase() }}</span></div>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Amount</label>
                            <input v-model="editInvoiceData.amount" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Account Head</label>
                            <select v-model="editInvoiceData.account_head_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                                <option value="">Select Account Head</option>
                                <option v-for="head in accountHeads" :key="head.id" :value="head.id">{{ head.name }}</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Session</label>
                            <select v-model="editInvoiceData.academic_session_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                                <option value="">Select Session</option>
                                <option v-for="session in sessionsSorted" :key="session.id" :value="session.id">{{ session.name }}</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Academic Level</label>
                            <select v-model="editInvoiceData.academic_qualification_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                                <option value="">Select Academic Level</option>
                                <option v-for="qual in qualifications" :key="qual.id" :value="qual.id">{{ qual.name }}</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Department/Group</label>
                            <select v-model="editInvoiceData.department_id" :disabled="!editInvoiceData.academic_qualification_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                                <option value="">Select Department</option>
                                <option v-for="dept in filteredEditDepartments" :key="dept.id" :value="dept.id">{{ dept.name }}</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Class</label>
                            <select v-model="editInvoiceData.academic_class_id" :disabled="!editInvoiceData.academic_qualification_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                                <option value="">Select Class</option>
                                <option v-for="cls in filteredEditClasses" :key="cls.id" :value="cls.id">{{ cls.name }}</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Exam</label>
                            <select v-model="editInvoiceData.exam_id" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                                <option value="">Select Exam</option>
                                <option v-for="exam in exams" :key="exam.id" :value="exam.id">{{ exam.name }}</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Exam Year</label>
                            <input v-model="editInvoiceData.examination_year" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" placeholder="Year" />
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Admission Roll</label>
                            <input v-model="editInvoiceData.admission_roll" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">College Roll</label>
                            <input v-model="editInvoiceData.college_roll" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Reg No</label>
                            <input v-model="editInvoiceData.reg_no" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Refund Amount</label>
                            <div class="mt-1 flex items-center">
                                <input v-model="refunded" type="checkbox" class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500" />
                                <label class="ml-2 text-sm text-slate-700">Are you sure?</label>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700">Payment Date</label>
                            <input v-model="editInvoiceData.payment_date" type="date" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                        </div>

                        <div v-if="refunded">
                            <label class="block text-sm font-medium text-slate-700">Refund Amount</label>
                            <input v-model="editInvoiceData.refund_amount" type="number" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" placeholder="Refund Amount" @input="calculateRefundAmount" />
                        </div>

                        <div v-if="refunded">
                            <label class="block text-sm font-medium text-slate-700">Refund Date</label>
                            <input v-model="editInvoiceData.refund_date" type="date" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
                        </div>

                        <div v-if="refunded" class="md:col-span-2">
                            <label class="block text-sm font-medium text-slate-700">Refund Note</label>
                            <textarea v-model="editInvoiceData.refund_note" class="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" rows="3" placeholder="Enter refund note..."></textarea>
                        </div>
                    </div>

                    <div class="mt-6 grid grid-cols-1 gap-3 md:grid-cols-2">
                        <button type="button" class="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50" :disabled="saving" @click="updateInfoOnly">
                            <i v-if="saving" class="fas fa-spinner fa-spin mr-2"></i>
                            <i v-else class="fas fa-edit mr-2"></i>
                            {{ saving ? 'Processing...' : 'Update Info Only' }}
                        </button>
                        <button type="button" class="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700" :disabled="saving" @click="paidAndUpdate">
                            <i v-if="saving" class="fas fa-spinner fa-spin mr-2"></i>
                            <i v-else class="fas fa-save mr-2"></i>
                            {{ saving ? 'Processing...' : 'Paid & Update Info' }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'InvoiceIndex',
    props: {
        systems: {
            type: Object,
            default: () => ({}),
        },
        mode: {
            type: String,
            default: '',
        },
    },
    data() {
        return {
            loading: false,
            error: '',
            rows: [],
            meta: { from: 0, to: 0, total: 0, current_page: 1, last_page: 1 },
            deletingId: null,
            showEditModal: false,
            saving: false,
            refunded: false,
            totalAmount: 0,
            searchTimer: null,
            editInvoiceData: {
                id: null,
                amount: '',
                status: '',
                current_status: '',
                invoice_number: '',
                account_head_id: '',
                academic_session_id: '',
                department_id: '',
                academic_qualification_id: '',
                academic_class_id: '',
                exam_id: '',
                examination_year: '',
                payment_date: '',
                refund_amount: '',
                refund_date: '',
                refund_note: '',
                admission_roll: '',
                college_roll: '',
                reg_no: '',
            },
            filters: {
                pagination: 15,
                status: 'success',
                date: false,
                academic_session_id: '',
                academic_qualification_id: '',
                department_id: '',
                academic_class_id: '',
                student_type: '',
                from_date: '',
                to_date: '',
                exam_id: '',
                examination_year: '',
                field_name: 'invoice_number',
                value: '',
                account_head_id: '',
                payment_gateway_id: '',
            },
        }
    },
    computed: {
        pageHeading() {
            if (this.mode === 'accountWise') return 'Account Wise Payment Report'
            if (this.mode === 'accountHeadWise') return 'Account Head Wise Payment Report'
            return 'Student Payment Report'
        },
        sessions() {
            const list = this.systems?.global?.academic_sessions
            return Array.isArray(list) ? list : []
        },
        sessionsSorted() {
            const list = [...this.sessions]
            const sortKey = (s) => {
                const name = String(s?.name || '').trim()
                const m = name.match(/(19|20)\d{2}/)
                return m ? Number(m[0]) : 0
            }
            return list.sort((a, b) => sortKey(b) - sortKey(a))
        },
        qualifications() {
            const list = this.systems?.global?.academic_qualifications
            return Array.isArray(list) ? list : []
        },
        classes() {
            const list = this.systems?.global?.academic_classes
            return Array.isArray(list) ? list : []
        },
        departments() {
            const list = this.systems?.global?.departments
            return Array.isArray(list) ? list : []
        },
        departmentQualifications() {
            const list = this.systems?.global?.department_qualidactions || this.systems?.global?.department_qualifications
            return Array.isArray(list) ? list : []
        },
        filteredDepartments() {
            const qid = this.filters?.academic_qualification_id
            if (!qid) return []
            const allowed = new Set(
                this.departmentQualifications
                    .filter((r) => String(r.academic_qualification_id) === String(qid))
                    .map((r) => String(r.department_id)),
            )
            return this.departments.filter((d) => allowed.has(String(d.id)))
        },
        filteredClasses() {
            const qid = this.filters?.academic_qualification_id
            if (!qid) return []
            return this.classes.filter((c) => String(c.academic_qualification_id) === String(qid))
        },
        exams() {
            const list = this.systems?.global?.exams
            return Array.isArray(list) ? list : []
        },
        studentTypes() {
            const list = this.systems?.global?.student_types
            return Array.isArray(list) ? list : []
        },
        accountHeads() {
            const list = this.systems?.global?.account_heads
            if (list && typeof list === 'object' && !Array.isArray(list)) {
                return Object.keys(list).map((id) => ({ id, name: list[id] }))
            }
            return Array.isArray(list) ? list : []
        },
        accountsCommons() {
            const list = this.systems?.global?.accounts_commons
            return Array.isArray(list) ? list : []
        },
        filteredEditDepartments() {
            const qid = this.editInvoiceData?.academic_qualification_id
            if (!qid) return []
            const allowed = new Set(
                this.departmentQualifications
                    .filter((r) => String(r.academic_qualification_id) === String(qid))
                    .map((r) => String(r.department_id)),
            )
            return this.departments.filter((d) => allowed.has(String(d.id)))
        },
        filteredEditClasses() {
            const qid = this.editInvoiceData?.academic_qualification_id
            if (!qid) return []
            return this.classes.filter((c) => String(c.academic_qualification_id) === String(qid))
        },
    },
    watch: {
        'filters.academic_qualification_id'(next, prev) {
            if (String(next || '') !== String(prev || '')) {
                this.filters.department_id = ''
                this.filters.academic_class_id = ''
                this.scheduleLoad(true)
            }
        },
        'editInvoiceData.academic_qualification_id'(next, prev) {
            if (String(next || '') !== String(prev || '')) {
                this.editInvoiceData.department_id = ''
                this.editInvoiceData.academic_class_id = ''
            }
        },
        filters: {
            handler() {
                this.scheduleLoad(true)
            },
            deep: true,
        },
    },
    created() {
        this.load(1)
    },
    methods: {
        scheduleLoad(resetPage) {
            if (this.searchTimer) clearTimeout(this.searchTimer)
            this.searchTimer = setTimeout(() => {
                const page = resetPage ? 1 : Number(this.meta?.current_page || 1)
                this.load(page)
            }, 250)
        },
        money(v) {
            const n = Number(v || 0)
            const val = Number.isFinite(n) ? n : 0
            return val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        },
        goDashboard() {
            window.history.pushState({}, '', '/admin/dashboard')
            window.dispatchEvent(new PopStateEvent('popstate'))
        },
        goCreate() {
            window.history.pushState({}, '', '/admin/invoice/create')
            window.dispatchEvent(new PopStateEvent('popstate'))
        },
        openInvoice(id) {
            window.history.pushState({}, '', `/admin/invoice/${id}`)
            window.dispatchEvent(new PopStateEvent('popstate'))
        },
        buildPrintQuery() {
            const q = { ...this.filters }
            delete q.pagination
            q.page = undefined
            const params = new URLSearchParams()
            Object.keys(q).forEach((k) => {
                const v = q[k]
                if (v === '' || v == null) return
                params.set(k, String(v))
            })
            return params.toString()
        },
        printInvoice() {
            const qs = this.buildPrintQuery()
            const url = qs ? `/admin/invoice-print?${qs}` : '/admin/invoice-print'
            window.location.href = url
        },
        async load(page = 1) {
            this.loading = true
            this.error = ''
            try {
                const res = await window.axios.get('/admin/invoice', {
                    params: { ...this.filters, page },
                })
                const data = res?.data || {}
                this.rows = Array.isArray(data.data) ? data.data : []
                this.meta = {
                    from: data.from || 0,
                    to: data.to || 0,
                    total: data.total || 0,
                    current_page: data.current_page || 1,
                    last_page: data.last_page || 1,
                }
            } catch (e) {
                this.rows = []
                this.meta = { from: 0, to: 0, total: 0, current_page: 1, last_page: 1 }
                this.error = e?.response?.data?.message || 'Failed to load invoices.'
            } finally {
                this.loading = false
            }
        },
        editInvoice(id) {
            const invoice = this.rows.find(row => row.id === id)
            if (!invoice) return

            const today = new Date().toISOString().slice(0, 10)
            
            // Calculate total amount (original amount + refund amount)
            this.totalAmount = parseFloat(invoice.amount || 0) + parseFloat(invoice.refund_amount || 0)
            
            // Set refund checkbox state
            this.refunded = invoice.refund_amount ? true : false
            
            this.editInvoiceData = {
                id: invoice.id,
                amount: invoice.amount || '',
                status: invoice.status || '',
                current_status: invoice.status || '',
                invoice_number: invoice.invoice_number || '',
                account_head_id: invoice.account_head_id || '',
                academic_session_id: invoice.academic_session_id || '',
                department_id: invoice.department_id || '',
                academic_qualification_id: invoice.academic_qualification_id || '',
                academic_class_id: invoice.academic_class_id || '',
                exam_id: invoice.exam_id || '',
                examination_year: invoice.examination_year || '',
                payment_date: invoice.payment_date || today,
                refund_amount: invoice.refund_amount || '',
                refund_date: invoice.refund_date || today,
                refund_note: invoice.refund_note || '',
                admission_roll: invoice.admission_id || '',
                college_roll: invoice.college_roll || '',
                reg_no: invoice.reg_no || '',
            }

            this.showEditModal = true
        },
        calculateRefundAmount() {
            // Calculate amount after refund
            const refundAmount = parseFloat(this.editInvoiceData.refund_amount || 0)
            this.editInvoiceData.amount = parseFloat(this.totalAmount) - refundAmount
        },
        async updateInfoOnly() {
            if (!confirm("Are you sure you want to update information without changing payment status?")) {
                return
            }
            
            this.saving = true
            try {
                await window.axios.put(`/admin/invoice/${this.editInvoiceData.id}`, this.editInvoiceData)
                this.showEditModal = false
                this.load(this.meta.current_page)
            } catch (e) {
                this.error = e?.response?.data?.message || 'Failed to update invoice.'
            } finally {
                this.saving = false
            }
        },
        async paidAndUpdate() {
            if (!confirm("Are you sure you want to mark as paid and update information?")) {
                return
            }
            
            this.saving = true
            try {
                await window.axios.put(`/admin/invoice/${this.editInvoiceData.id}`, this.editInvoiceData)
                this.showEditModal = false
                this.load(this.meta.current_page)
            } catch (e) {
                this.error = e?.response?.data?.message || 'Failed to update invoice.'
            } finally {
                this.saving = false
            }
        },
        formatDate(dateString) {
            if (!dateString) return ''
            
            const date = new Date(dateString)
            const options = { year: 'numeric', month: 'short', day: 'numeric' }
            return date.toLocaleDateString('en-US', options)
        },
        async deleteInvoice(id) {
            if (!confirm('Are you sure you want to delete this invoice?')) {
                return
            }
            
            this.deletingId = id
            try {
                await window.axios.delete(`/admin/invoice/${id}`)
                this.load(this.meta.current_page)
            } catch (e) {
                this.error = e?.response?.data?.message || 'Failed to delete invoice.'
            } finally {
                this.deletingId = null
            }
        },
    },
}
</script>
